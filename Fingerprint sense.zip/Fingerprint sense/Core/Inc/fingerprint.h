#ifndef FINGERPRINT_H
#define FINGERPRINT_H

#include "main.h"
#include <stdint.h>
#include <stdbool.h>

// Include Adafruit command/status defines here.
#include "fingerprint_defs.h"

// public API
void fingerprint_init(UART_HandleTypeDef *huart);
void fingerprint_set_device_address(uint32_t address); // optional if you need to change

// Capture image: returns status code from library (FINGERPRINT_OK / FINGERPRINT_NOFINGER / ...)
uint8_t fingerprint_get_image(void);

// Convert latest image to template slot (slot = 1 or 2)
uint8_t fingerprint_image2Tz(uint8_t slot);

// Create model (combine slot1 & slot2)
uint8_t fingerprint_create_model(void);

// Store model to location (0..N)
uint8_t fingerprint_store_model(uint16_t location);

// Search templates, returns status (FINGERPRINT_OK on match)
uint8_t fingerprint_search(uint8_t slot);

// High-level: perform a full identify attempt, returns ID >=0 if matched, -1 on not found, -2 on comm error
int fingerprint_identify(void);

// Read template count
uint8_t fingerprint_get_template_count(uint16_t *count_out);

// Empty DB
uint8_t fingerprint_empty_database(void);

// helper to change LED or security if needed (optional)
uint8_t fingerprint_LED_control(uint8_t ctrl, uint8_t speed, uint8_t coloridx, uint8_t count);

#endif // FINGERPRINT_H