#include "fingerprint.h"
#include <string.h>
#include <stdio.h>

// Default device address (Adafruit default) - can be overwritten with fingerprint_set_device_address
static uint32_t device_address = 0xFFFFFFFFUL;
static UART_HandleTypeDef *fp_uart = NULL;

// packet helpers
#define START_CODE_HIGH  ((uint8_t)((FINGERPRINT_STARTCODE >> 8) & 0xFF))
#define START_CODE_LOW   ((uint8_t)(FINGERPRINT_STARTCODE & 0xFF))

// Internal send/receive timeouts
#define FP_TX_TIMEOUT 100
#define FP_RX_TIMEOUT 2000

// Max buffer for receiving bytes (safe size)
#define FP_RX_BUF_SIZE 300

// Low-level: send structured packet (command type)
static void fp_send_command_packet(const uint8_t *data, uint16_t data_len) {
    // build framed packet: start(2) + address(4) + packet_type(1) + length(2) + payload(data_len) + checksum(2)
    uint16_t wire_len = data_len + 2; // length = payload_len + checksum(2)
    // header
    uint8_t hdr[9];
    hdr[0] = START_CODE_HIGH;
    hdr[1] = START_CODE_LOW;
    hdr[2] = (uint8_t)((device_address >> 24) & 0xFF);
    hdr[3] = (uint8_t)((device_address >> 16) & 0xFF);
    hdr[4] = (uint8_t)((device_address >> 8) & 0xFF);
    hdr[5] = (uint8_t)(device_address & 0xFF);
    hdr[6] = FINGERPRINT_COMMANDPACKET;
    hdr[7] = (uint8_t)((wire_len >> 8) & 0xFF);
    hdr[8] = (uint8_t)(wire_len & 0xFF);

    HAL_UART_Transmit(fp_uart, hdr, sizeof(hdr), FP_TX_TIMEOUT);

    uint16_t checksum = 0;
    checksum += hdr[7]; checksum += hdr[8];
    checksum += hdr[6];

    // payload
    for (uint16_t i = 0; i < data_len; ++i) {
        HAL_UART_Transmit(fp_uart, (uint8_t *)&data[i], 1, FP_TX_TIMEOUT);
        checksum += data[i];
    }

    // checksum
    uint8_t ck[2];
    ck[0] = (uint8_t)((checksum >> 8) & 0xFF);
    ck[1] = (uint8_t)(checksum & 0xFF);
    HAL_UART_Transmit(fp_uart, ck, 2, FP_TX_TIMEOUT);
}

// Low-level: receive ONE structured packet into buffer, return packet type and data pointer/len via out params.
// This function blocks up to 'timeout_ms' for the entire packet.
static int fp_receive_packet(uint8_t *out_type, uint8_t *out_data, uint16_t *out_len, uint32_t timeout_ms)
{
    uint8_t header[9];

    // ---- Step 1: read fixed 9-byte header ----
    if (HAL_UART_Receive(fp_uart, header, 9, timeout_ms) != HAL_OK) {
        return -1;
    }

    // Validate header
    if (header[0] != 0xEF || header[1] != 0x01) {
        return -3; // bad start code
    }

    uint8_t packet_type = header[6];
    uint16_t wire_len = ((uint16_t)header[7] << 8) | header[8]; // includes checksum

    uint16_t data_len = wire_len - 2; // exclude checksum

    // ---- Step 2: read payload (data + checksum) ----
    uint8_t payload[256];
    if (HAL_UART_Receive(fp_uart, payload, wire_len, timeout_ms) != HAL_OK) {
        return -4; // timeout during payload
    }

    // Copy data
    if (data_len > 0) {
        memcpy(out_data, payload, data_len);
    }

    *out_type = packet_type;
    *out_len  = data_len;

    return 0;
}

// public API implementations

void fingerprint_init(UART_HandleTypeDef *huart) {
    fp_uart = huart;
}

void fingerprint_set_device_address(uint32_t address) {
    device_address = address;
}

// Helper: send command and receive ACK packet; returns first data byte (ACK code) or negative on error
static int fp_send_command_and_get_ack(const uint8_t *cmd_data, uint16_t cmd_len, uint8_t *ack_code_out, uint8_t *resp_data, uint16_t *resp_len) {
    if (!fp_uart) return -1;
    fp_send_command_packet(cmd_data, cmd_len);
    uint8_t ptype = 0;
    uint16_t dlen = 0;
    int r = fp_receive_packet(&ptype, resp_data, &dlen, FP_RX_TIMEOUT);
    if (r != 0) return -2;
    if (ptype != FINGERPRINT_ACKPACKET) return -3;
    if (dlen >= 1) {
        *ack_code_out = resp_data[0];
    } else {
        *ack_code_out = 0xFF;
    }
    if (resp_len) *resp_len = dlen;
    return 0;
}

uint8_t fingerprint_get_image(void) {
    uint8_t cmd[1];
    cmd[0] = FINGERPRINT_GETIMAGE;
    uint8_t ack = 0;
    uint8_t resp[FP_RX_BUF_SIZE];
    uint16_t rlen = 0;
    int r = fp_send_command_and_get_ack(cmd, 1, &ack, resp, &rlen);
    printf("ACK=%02X, r=%d\r\n", ack, r);
    if (r != 0) return FINGERPRINT_PACKETRECIEVEERR;
    return ack; // expected FINGERPRINT_OK or FINGERPRINT_NOFINGER etc.
}

uint8_t fingerprint_image2Tz(uint8_t slot) {
    uint8_t cmd[2];
    cmd[0] = FINGERPRINT_IMAGE2TZ;
    cmd[1] = slot;
    uint8_t ack = 0; uint8_t resp[FP_RX_BUF_SIZE]; uint16_t rlen = 0;
    int r = fp_send_command_and_get_ack(cmd, sizeof(cmd), &ack, resp, &rlen);
    if (r != 0) return FINGERPRINT_PACKETRECIEVEERR;
    return ack;
}

uint8_t fingerprint_create_model(void) {
    uint8_t cmd[1] = { FINGERPRINT_REGMODEL };
    uint8_t ack = 0; uint8_t resp[FP_RX_BUF_SIZE]; uint16_t rlen = 0;
    if (fp_send_command_and_get_ack(cmd, 1, &ack, resp, &rlen) != 0) return FINGERPRINT_PACKETRECIEVEERR;
    return ack;
}

uint8_t fingerprint_store_model(uint16_t location) {
    uint8_t cmd[4];
    cmd[0] = FINGERPRINT_STORE;
    cmd[1] = 0x01; // buffer id
    cmd[2] = (uint8_t)((location >> 8) & 0xFF);
    cmd[3] = (uint8_t)(location & 0xFF);
    uint8_t ack = 0; uint8_t resp[FP_RX_BUF_SIZE]; uint16_t rlen = 0;
    if (fp_send_command_and_get_ack(cmd, sizeof(cmd), &ack, resp, &rlen) != 0) return FINGERPRINT_PACKETRECIEVEERR;
    return ack;
}

uint8_t fingerprint_search(uint8_t slot) {
    // slot, start page (2 bytes), range (2 bytes)
    uint16_t startpage = 0x0000;
    uint16_t count = 0x00A3; // typical capacity
    uint8_t cmd[6];
    cmd[0] = FINGERPRINT_HISPEEDSEARCH; // or FINGERPRINT_SEARCH depending on define; use HISPEED for faster search
    cmd[1] = slot;
    cmd[2] = (uint8_t)((startpage >> 8) & 0xFF);
    cmd[3] = (uint8_t)(startpage & 0xFF);
    cmd[4] = (uint8_t)((count >> 8) & 0xFF);
    cmd[5] = (uint8_t)(count & 0xFF);
    uint8_t ack = 0; uint8_t resp[FP_RX_BUF_SIZE]; uint16_t rlen = 0;
    if (fp_send_command_and_get_ack(cmd, sizeof(cmd), &ack, resp, &rlen) != 0) return FINGERPRINT_PACKETRECIEVEERR;
    // When matched, resp contains: [ACK][IDhigh][IDlow][ConfHigh][ConfLow]
    // ack contains the status (FINGERPRINT_OK on success)
    if (ack == FINGERPRINT_OK && rlen >= 5) {
        // copy result into resp (caller could inspect global fields if we wanted)
    }
    return ack;
}

int fingerprint_identify(void) {
    // Full flow that tries to capture image, convert and search
    uint8_t p;
    // --- 1. Capture finger image ---
	p = fingerprint_get_image();
	if (p != FINGERPRINT_OK) {
		if (p == FINGERPRINT_NOFINGER) {
			printf("[DEBUG] No finger detected (get_image ACK=%02X)\r\n", p);
			return -1;
		} else {
			printf("[DEBUG] Error reading image (get_image ACK=%02X)\r\n", p);
			return -2;
		}
	}
	printf("[DEBUG] Finger detected, get_image ACK=%02X\r\n", p);

	// --- 2. Convert image to template ---
	p = fingerprint_image2Tz(1);
	if (p != FINGERPRINT_OK) {
		printf("[DEBUG] Failed to convert image to template (image2Tz ACK=%02X)\r\n", p);
		return -3;
	}
	printf("[DEBUG] Image converted to template buffer 1 (ACK=%02X)\r\n", p);

	// --- 3. High-speed search ---
	uint8_t cmd[6];
	uint16_t startpage = 0x0000;
	uint16_t count = 0x00A3;

	cmd[0] = FINGERPRINT_HISPEEDSEARCH;
	cmd[1] = 0x01; // buffer 1
	cmd[2] = (startpage >> 8) & 0xFF;
	cmd[3] = startpage & 0xFF;
	cmd[4] = (count >> 8) & 0xFF;
	cmd[5] = count & 0xFF;

	fp_send_command_packet(cmd, sizeof(cmd));

	uint8_t ptype = 0;
	uint8_t resp[FP_RX_BUF_SIZE];
	uint16_t rlen = 0;
	int r = fp_receive_packet(&ptype, resp, &rlen, FP_RX_TIMEOUT);

	if (r != 0) {
		printf("[DEBUG] Failed to receive search response, r=%d\r\n", r);
		return -4;
	}
	if (ptype != FINGERPRINT_ACKPACKET) {
		printf("[DEBUG] Unexpected packet type: %02X\r\n", ptype);
		return -5;
	}
	if (rlen < 5) {
		printf("[DEBUG] Response too short: %d bytes\r\n", rlen);
		return -6;
	}

	uint8_t ackcode = resp[0];
	if (ackcode != FINGERPRINT_OK) {
		printf("[DEBUG] Search ACK indicates no match or error: ACK=%02X\r\n", ackcode);
		return -7;
	}

	uint16_t id = ((uint16_t)resp[1] << 8) | resp[2];
	uint16_t confidence = ((uint16_t)resp[3] << 8) | resp[4];

	printf("[DEBUG] Match found! ID=%d, Confidence=%d\r\n", id, confidence);
	return (int)id;
}

uint8_t fingerprint_get_template_count(uint16_t *count_out) {
    uint8_t cmd[1] = { FINGERPRINT_TEMPLATECOUNT };
    uint8_t ack = 0; uint8_t resp[FP_RX_BUF_SIZE]; uint16_t rlen = 0;
    if (fp_send_command_and_get_ack(cmd, 1, &ack, resp, &rlen) != 0) return FINGERPRINT_PACKETRECIEVEERR;
    if (ack == FINGERPRINT_OK && rlen >= 3) {
        uint16_t cnt = ((uint16_t)resp[1] << 8) | resp[2];
        if (count_out) *count_out = cnt;
    }
    return ack;
}

uint8_t fingerprint_empty_database(void) {
    uint8_t cmd[1] = { FINGERPRINT_EMPTY };
    uint8_t ack = 0; uint8_t resp[FP_RX_BUF_SIZE]; uint16_t rlen = 0;
    if (fp_send_command_and_get_ack(cmd, 1, &ack, resp, &rlen) != 0) return FINGERPRINT_PACKETRECIEVEERR;
    return ack;
}

uint8_t fingerprint_LED_control(uint8_t ctrl, uint8_t speed, uint8_t coloridx, uint8_t count) {
    uint8_t cmd[5];
    cmd[0] = FINGERPRINT_AURALEDCONFIG;
    cmd[1] = ctrl;
    cmd[2] = speed;
    cmd[3] = coloridx;
    cmd[4] = count;
    uint8_t ack = 0; uint8_t resp[FP_RX_BUF_SIZE]; uint16_t rlen = 0;
    if (fp_send_command_and_get_ack(cmd, sizeof(cmd), &ack, resp, &rlen) != 0) return FINGERPRINT_PACKETRECIEVEERR;
    return ack;
}
